import re

def check_password_strength(password):
    # Check the minimum length
    if len(password) < 8:
        return False

    # Check for at least one uppercase letter
    if not any(c.isupper() for c in password):
        return False

    # Check for at least one lowercase letter
    if not any(c.islower() for c in password):
        return False

    # Check for at least one digit
    if not any(c.isdigit() for c in password):
        return False

    # Check for at least one special character
    if not re.search(r'[!@#$%^&*()_+{}[\]:;<>,.?~\\\-]', password):
        return False

    # If all checks pass, the password is strong
    return True

# Test the function
password = input("Enter a password: ")
if check_password_strength(password):
    print("Password is strong!")
else:
    print("Password is weak. Please follow the criteria.")
    print("Minimum length: The password should be at least 8 characters long.")
    print("Contains both uppercase and lowercase letters.")
    print("Contains at least one digit (0-9).")
    print("Contains at least one special character (e.g., !, @, #, $, %).")
