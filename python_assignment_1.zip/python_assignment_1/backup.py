# python backup.py source_directory destination_directory
# This script will create a backup of files from the source directory to the destination directory, ensuring uniqueness by appending timestamps to filenames if necessary and handling errors gracefully.
import os
import shutil
import sys
from datetime import datetime

def copy_with_timestamp(src_path, dest_path, filename):
    # Append a timestamp to the filename to ensure uniqueness
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    base, ext = os.path.splitext(filename)
    new_filename = f"{base}_{timestamp}{ext}"
    shutil.copy(os.path.join(src_path, filename), os.path.join(dest_path, new_filename))

def backup_files(source_dir, dest_dir):
    # Check if source directory exists
    if not os.path.exists(source_dir):
        print(f"Source directory '{source_dir}' does not exist.")
        return

    # Create destination directory if it doesn't exist
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)

    # List all files in the source directory
    source_files = os.listdir(source_dir)

    for filename in source_files:
        source_file_path = os.path.join(source_dir, filename)
        dest_file_path = os.path.join(dest_dir, filename)

        # Check if a file with the same name already exists in the destination directory
        while os.path.exists(dest_file_path):
            print(f"File '{filename}' already exists in the destination directory.")
            copy_with_timestamp(source_dir, dest_dir, filename)
            filename = f"{os.path.splitext(filename)[0]}_{datetime.now().strftime('%Y%m%d%H%M%S')}{os.path.splitext(filename)[1]}"
            dest_file_path = os.path.join(dest_dir, filename)

        # Copy the file to the destination directory
        shutil.copy(source_file_path, dest_file_path)
        print(f"Copied '{filename}' to '{dest_dir}'")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python backup.py source_dir dest_dir")
    else:
        source_dir = sys.argv[1]
        dest_dir = sys.argv[2]
        backup_files(source_dir, dest_dir)





